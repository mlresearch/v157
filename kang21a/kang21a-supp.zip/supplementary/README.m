%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Folder: Code for MLE

% This folder contains the code to implement the
% first type of MLE technique for hashes with
% binary / discrete outputs

% You can create a file with a (vectorized)
% version of a hashing algorithm to verify 

% Here is a brief explanation of the script files 
% in this folder. 

% run_expt_parallel.m is the main function
% which runs the simulations as described in the paper
% This function computes the overall RMSE of all pairs
% of vectors in the dataset (estimated value versus
% true value).
% RMSE is evaluated "block by block", of 250 by 250
% pairwise distances at a time. 


% Three function files are used
%   simple_efficient_hash_info.m (simple & efficient hashing)
%   SRP_SBLSH_hash_info.m (SRP / SBLSH)
%   minwise_hash_info (minwise hashing / bbit hashing)

% Each of these three files do the following:

  %  - kvec (initialize num hashes)
  %  - gen_extra_vec (type of extra_vec)
  %  - store_prob (store p_iw, p_jw)
  %  - create_results_vec (store results)
  %  - gen_Y (get Y after random hashes)
  %  - true_vals (compute true values of quantity of interest)
  %  - compute_ests (compute estimates using extra info)
  %  - convert_naive_prob_to_est (covert prob to estimates ; corresponds to f^{-1}(1) in paper)
  %  - convert_better_prob_to_est (covert prob to estimates ; corresponds to f^{-1}(1) in paper)

% the function get_hash_Y_passon.m consolidates the
% above functions

% To test this out on a hashing algorithm
% with discrete or binary inputs, create a matlab file
% similar to the three functions above, that outputs
% the relevant values 
% and edit the following functions
%     get_hash_Y_passon.m  (incorporate your file)
%     run_expt_parallel.m 

% Other functions in the folder are helper functions
% and here is a brief description of them
%
% compute_binary_extra_info.m
% compute_discrete_extra_info.m
%  These functions output the count of nA, nB, nC, nD
%  and nE in the paper

% newton_raphson_for_binary_prob.m
% newton_raphson_for_discrete_prob.m 
%  These functions run vectorized newton raphson to find
%  the better estimates

% find_generic_rmse.m
% get_partitions_for_data
% normalize_matrix_obs
% update_results_expt
%  These are helper functions to help run simulations

% script.m
% patch_array.m
%  These are files which run the simulations, and patch
%  them at the end

