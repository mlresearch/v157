
parpool


% The following code assumes 10 cores, each function
% runs for 10 iterations, total 100 iterations

% Fill in parameters and algorithm of choice

%is_center = true;
%data_name = 'MNIST';
%algo_name = 'SRP'    
%bbit_val = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

parfor i = 1:10
    if i == 1
      i
    [results] = run_expt_parallel(X,data_name, algo_name,  '01', is_center, bbit_val);
    elseif i == 2
      i
    [results] = run_expt_parallel(X,data_name, algo_name,  '02', is_center, bbit_val);
    elseif i == 3
      i
    [results] = run_expt_parallel(X,data_name, algo_name,  '03', is_center, bbit_val);
    elseif i == 4
      i
    [results] = run_expt_parallel(X,data_name, algo_name,  '04', is_center, bbit_val);
    elseif i == 5
      i
    [results] = run_expt_parallel(X,data_name, algo_name,  '05', is_center, bbit_val);
    elseif i == 6
      i
    [results] = run_expt_parallel(X,data_name, algo_name,  '06', is_center, bbit_val);
    elseif i == 7
      i
    [results] = run_expt_parallel(X,data_name, algo_name,  '07', is_center, bbit_val);
    elseif i == 8
      i
    [results] = run_expt_parallel(X,data_name, algo_name,  '08', is_center, bbit_val);
    elseif i == 9
      i
    [results] = run_expt_parallel(X,data_name, algo_name,  '09', is_center, bbit_val);
    elseif i == 10
      i
    [results] = run_expt_parallel(X,data_name, algo_name,  '10', is_center, bbit_val);
    end
end
