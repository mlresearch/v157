function [results] = update_results_expt(iterVals,para,X,writeto_info, results)
 

    expr = iterVals.xseg == iterVals.yseg;

    iter_num = iterVals.iter_num;
    kvals = iterVals.kvals;

    results.ord_RMSE(iter_num,kvals) = results.ord_RMSE(iter_num,kvals) + find_generic_rmse(iterVals.sim_naive, iterVals.true_vals, expr);

    results.MLE_RMSE(iter_num,kvals) = results.MLE_RMSE(iter_num,kvals) + find_generic_rmse(iterVals.sim_better, iterVals.true_vals, expr);


end


