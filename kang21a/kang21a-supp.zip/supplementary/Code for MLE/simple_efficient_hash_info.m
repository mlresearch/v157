function [val] = simple_efficient_hash_info(iterVals, para, X, writeto_info, results,compute_type)

  % Place the following here, generally in order
  %  - kvec (initialize num hashes)
  %  - gen_extra_vec (type of extra_vec)
  %  - store_prob (store p_iw, p_jw)
  %  - create_results_vec (store results)
  %  - gen_Y (get Y after random hashes)
  %  - true_vals (compute true values of quantity of interest)
  %  - compute_ests (compute estimates using extra info)
  %  - convert_naive_prob_to_est (covert prob to estimates ; corresponds to f^{-1}(1) in paper)
  %  - convert_better_prob_to_est (covert prob to estimates ; corresponds to f^{-1}(1) in paper)

  if strcmp(compute_type, 'kvec')
    para.kvec = [20:20:500]; 

    if para.b == 1
      para.is_bin = true;
    else
      para.is_bin = false
    end
    val = para;
  
  elseif strcmp(compute_type, 'gen_extra_vec')
    
    
    if strcmp(para.algo_name, 'anshuhash_bin')
      val = zeros(1, size(X,2));
      medX = median(sum(X,2));
      sumX = sum(X,1);
      [tmp ind] = sort(sumX,'descend');
      val(ind(1:medX)) = 1;
      
   
      tmp_intersect = (X*transpose(val))';
      tmp_unioned = sum(bsxfun(@or, val,X),2)';
      tmp_res = tmp_intersect./ tmp_unioned;
    end  

  elseif strcmp(compute_type, 'store_prob')
    % What p_xe is this algorithm storing?
    % See get_true_vals_algo.m where this is used.
    %  Given an extra vector w_{1 x p}, compute and store the true
    %  probability p(w,x_i) for all i

    % ordinary minhash (at least for binary)
    tmpa = sum(min(X, para.w),2);
    tmpb = sum(max(X, para.w),2);
    val = tmpa./tmpb;
  elseif strcmp(compute_type, 'create_results_vec')

  
    val.ord_RMSE = zeros(iterVals.max_iter,length(para.kvec));
    val.MLE_RMSE = zeros(iterVals.max_iter,length(para.kvec));

  elseif strcmp(compute_type, 'gen_Y')
    % What smaller Y is this algorithm storing?

    k = para.K;
    p = para.p;
    n = para.N;
    val = zeros(size(X,1),k);
    
    for j = 1:k
      [~,val(:,j)] = max(X(:,unidrnd(p, [1 p])),[],2);
    end
    val = reshape(val,size(val,1),para.kidx(1,3),size(para.kidx,1));

  elseif strcmp(compute_type, 'true_vals')
    % What true_vals does this algorithm compute?
    %   In general, given two matrices X1_{n1 x p), X2_{n2 x p)} ; compute
    %   the true distance matrix D_{n1 x n2}, where d_{ij} is the distance
    %   between X1_{i.} and X2_{j.}

    % minhash / bbit computes resemblance
    Y1 = X(para.partition_start(iterVals.xseg):para.partition_end(iterVals.xseg),:);
    Y2 = X(para.partition_start(iterVals.yseg):para.partition_end(iterVals.yseg),:);

    intersected = full(Y1 *Y2');  
  
    unioned = zeros(iterVals.lenY1,iterVals.lenY2);
      
    for i = 1:iterVals.lenY1
      unioned(i,:) = sum(bsxfun(@or, (Y1(i,:)),(Y2)),2)';
    end

    val = intersected ./ unioned;
    % for 0/0 cases, i.e. must have zero resemblance
    val(isnan(val)) = 0;


  elseif strcmp(compute_type, 'compute_ests')
    % How are the estimates in contingency table computed?
    val = compute_discrete_extra_info(para, iterVals);

  elseif strcmp(compute_type, 'convert_naive_prob_to_est') || strcmp(compute_type, 'convert_better_prob_to_est')

    if strcmp(compute_type, 'convert_naive_prob_to_est') 
      prob_to_use = iterVals.naive_prob;
    elseif strcmp(compute_type, 'convert_better_prob_to_est')
      prob_to_use = iterVals.better_prob;
    end
    val = prob_to_use;
  end
end


