% Example of patch_array to patch files together

typeof = 'anshuhash_bin'
name = 'NIPS';
cent = 'uncentered';

patched_results.ord_RMSE = zeros(100,25);
patched_results.MLE_RMSE = zeros(100,25);

idx_start = 1:10:91;
idx_end = 10:10:100;


file_to_load = [typeof, '_',name,'_',cent,'_FINAL'];

file_to_save = [typeof, '_', cent, '_',name, '_100_iterations']


for j = 1:10
  
  if j < 10
  	filestr = [file_to_load, '0',num2str(j)];
  else
    filestr = [file_to_load, '10'];
  end
  load(filestr)
  ['patching ' filestr]
  % place here
	patched_results.ord_RMSE(idx_start(j):idx_end(j),:) = results.ord_RMSE;
	patched_results.MLE_RMSE(idx_start(j):idx_end(j),:) = results.MLE_RMSE;
  clear results;
end

results = patched_results;

save(file_to_save,'results')




