function [iterVals] = newton_raphson_for_discrete_prob(iterVals)
  
  nA = iterVals.small_nA;
  nB = iterVals.small_nB;
  nC = iterVals.small_nC;
  nD = iterVals.small_nD;
  nE = iterVals.small_nE;

  p_jw = iterVals.p_jw;
  p_iw = iterVals.p_iw; 


  TOL = 1e-8;          % Initialize tolerance
  max_iter = 100;      % and max iterations
  iter = 0;            % and starting number of iter


  tot_size = prod(size(nA));
  orig_size = size(nA);

  nA = reshape(nA, 1, tot_size);
  nB = reshape(nB, 1, tot_size);
  nC = reshape(nC, 1, tot_size);
  nD = reshape(nD, 1, tot_size);
  nE = reshape(nE, 1, tot_size);
  p_jw = reshape(p_jw, 1, tot_size);
  p_iw = reshape(p_iw, 1, tot_size);

  % find zeroidx
  un1 = union(find(nA == 0), find(nB == 0));
  un2 = union(find(nC == 0), find(nD == 0));
  un3 = union(un1,un2);
  badvaridx = union(un3,find(nE == 0));


  a_now = ones(1,tot_size) .* nA./(nA+nB+nC+nD+nE);

  len_a = length(nA);

  a_prev = zeros(1, len_a);

  % Terminate also when no more elements to do NR over 
  is_term = len_a;
  
  % Check number of idxes to go ; we stop iterating an element when TOL is met
  idx_to_go = 1:len_a;

  while is_term > 0 && iter < max_iter

    iter = iter + 1;
    
    % Update the indexes where we need to continue doing NR

    % Update steps
    % Gotta ifcheck for appropriate idx_to_go (above >0 or not)
    a_prev(idx_to_go) = a_now(idx_to_go);

	  [ fx, dfx ] = local_NR_for_pA( a_now(idx_to_go), nA(idx_to_go), nB(idx_to_go), nC(idx_to_go), nD(idx_to_go), nE(idx_to_go), p_iw(idx_to_go), p_jw(idx_to_go));       

	    a_now(idx_to_go) = a_now(idx_to_go) - fx./dfx;

	    % check which points to still iterate on    
	    idx_to_go = idx_to_go(abs(a_now(idx_to_go) - a_prev(idx_to_go)) > TOL);
	  
    is_term = length(idx_to_go) ;%+ length(idx_to_go_theta2);

  end

  zeroidx = find(nE+nD == 0);
  zeroidx = union(zeroidx, isnan(a_now));
  iterVals.better_prob = a_now + nD.*(1+a_now -p_iw - p_jw)./(nE + nD);
  if zeroidx ~= 0
    iterVals.better_prob(zeroidx) = a_now(zeroidx);
  end

  naive_prob = reshape(iterVals.naive_prob, 1, tot_size);
  
  % If we have not converged, replace with naive estimate
  iterVals.better_prob(idx_to_go) = naive_prob(idx_to_go);

  % If we have any nA nB nC nD nE = 0, replace with naive estimate (worse var)
  iterVals.better_prob(badvaridx) = naive_prob(badvaridx);

  % If we have any NaN entries, replace with naive estimate
  iterVals.better_prob(isnan(iterVals.better_prob)) = naive_prob(isnan(iterVals.better_prob));

  % If we converge outside of limits, set them to limits
  iterVals.better_prob(iterVals.better_prob < 0) = 0;
  iterVals.better_prob(iterVals.better_prob > 1) = 1;

  iterVals.better_prob = reshape(iterVals.better_prob, orig_size);
  
end



function [ fx, dfx ] = local_NR_for_pA( pA, nA, nB, nC, nD, nE, p_iw, p_jw )

  
  psums = p_iw + p_jw;

  a3coef = (nA + nB + nC + nD + nE);

  a2coef = nB + nC - (2 * nB + nC + nD + nE) .* p_iw + nA .*(1 - 2 *psums) - (nB + 2 * nC + nD + nE) .* p_jw;


  a1coef = (nD + nE) .* p_iw .* p_jw + nB .* p_iw .* (psums - 1) + nC .* p_jw .* (psums - 1) + nA .* (p_iw.^2 + (-1 + p_jw) .* p_jw + p_iw .* (-1 + 3 .* p_jw));

  a0coef = -nA .* p_iw .* p_jw .* (psums - 1);

  fx = a3coef .* pA.^3 + a2coef .* pA.^2  + pA .* a1coef + a0coef;
  dfx = 3 * a3coef .* pA.^2 + 2 * (pA .* a2coef) +a1coef;

end

